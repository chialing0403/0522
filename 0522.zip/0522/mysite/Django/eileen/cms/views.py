from django.shortcuts import render_to_response
# Create your views here.
from .models import  me, fam

def index(request):
	mes = me.objects.all()	
	return render_to_response('cms/menu.html',locals())

def object(request):
	fams = fam.object.all()	
	return render_to_response('cms/menu.html',locals())

	
