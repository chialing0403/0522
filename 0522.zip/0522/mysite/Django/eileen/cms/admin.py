from django.contrib import admin
from .models import me, fam
# Register your models here.

class meAdmin(admin.ModelAdmin):
	list_display = ('name', 'student ID', 'residence')
class famAdmin(admin.ModelAdmin):
	list_display = ('family','familyname')


admin.site.register(me)
admin.site.register(fam)